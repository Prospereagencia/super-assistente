"""
Script para validar configurações do .env
"""

import os
from dotenv import load_dotenv

def validate_config():
    """Valida se todas as configurações necessárias estão presentes"""
    
    # Carregar variáveis do .env
    load_dotenv()
    
    print("🔧 Validando configurações...")
    print("=" * 50)
    
    # Configurações obrigatórias
    required_configs = {
        'EVOLUTION_API_URL': 'URL da Evolution API',
        'EVOLUTION_API_KEY': 'Chave da Evolution API',
        'EVOLUTION_INSTANCE_NAME': 'Nome da instância Evolution',
        'OPENAI_API_KEY': 'Chave da OpenAI API'
    }
    
    # Configurações opcionais
    optional_configs = {
        'GOOGLE_CREDENTIALS_FILE': 'Arquivo de credenciais Google',
        'DEBUG': 'Modo debug',
        'LOG_LEVEL': 'Nível de log',
        'TIMEZONE': 'Fuso horário',
        'LANGUAGE': 'Idioma'
    }
    
    missing_required = []
    
    print("📋 Configurações obrigatórias:")
    for key, description in required_configs.items():
        value = os.getenv(key)
        if value and value != f"sua_{key.lower()}_aqui":
            print(f"✅ {key}: {description} - Configurado")
        else:
            print(f"❌ {key}: {description} - NÃO CONFIGURADO")
            missing_required.append(key)
    
    print("\n📋 Configurações opcionais:")
    for key, description in optional_configs.items():
        value = os.getenv(key)
        if value:
            print(f"✅ {key}: {description} - {value}")
        else:
            print(f"⚠️  {key}: {description} - Não configurado")
    
    print("\n" + "=" * 50)
    
    if missing_required:
        print("❌ CONFIGURAÇÃO INCOMPLETA!")
        print("Você precisa configurar:")
        for key in missing_required:
            print(f"   - {key}")
        print("\nEdite o arquivo .env com suas credenciais reais.")
        return False
    else:
        print("✅ CONFIGURAÇÃO COMPLETA!")
        print("Todas as configurações obrigatórias estão presentes.")
        return True

def show_setup_guide():
    """Mostra guia de configuração"""
    
    guide = """
🚀 GUIA DE CONFIGURAÇÃO

1. EVOLUTION API:
   - Obtenha sua URL e chave da Evolution API
   - Configure EVOLUTION_API_URL, EVOLUTION_API_KEY e EVOLUTION_INSTANCE_NAME

2. OPENAI API:
   - Crie uma conta em https://platform.openai.com/
   - Gere uma chave API em https://platform.openai.com/api-keys
   - Configure OPENAI_API_KEY

3. GOOGLE APIS (Opcional):
   - Acesse https://console.cloud.google.com/
   - Ative as APIs: Gmail, Calendar, Drive
   - Baixe o arquivo credentials.json
   - Coloque na pasta raiz do projeto

4. TESTE:
   - Execute: python validate_config.py
   - Execute: python test_imports.py
   - Execute: python main.py
"""
    
    print(guide)

if __name__ == "__main__":
    print("🔧 VALIDADOR DE CONFIGURAÇÃO")
    print("=" * 50)
    
    # Verificar se arquivo .env existe
    if not os.path.exists('.env'):
        print("❌ Arquivo .env não encontrado!")
        print("Crie o arquivo .env baseado no .env.example")
        show_setup_guide()
    else:
        is_valid = validate_config()
        if not is_valid:
            print("\n📖 Precisa de ajuda? Execute:")
            print("python validate_config.py --help")
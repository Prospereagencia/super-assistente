/*
  Warnings:

  - You are about to drop the column `name` on the `is_on_whatsapp` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "is_on_whatsapp" DROP COLUMN "name";

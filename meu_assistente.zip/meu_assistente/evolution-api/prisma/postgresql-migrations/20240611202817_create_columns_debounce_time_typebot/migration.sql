-- AlterTable
ALTER TABLE "Typebot" ADD COLUMN     "debounceTime" INTEGER;

-- AlterTable
ALTER TABLE "TypebotSetting" ADD COLUMN     "debounceTime" INTEGER;

-- AlterTable
ALTER TABLE "Chat" ADD COLUMN     "name" VARCHAR(100);

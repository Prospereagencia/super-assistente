-- AlterTable
ALTER TABLE "Chatwoot" ADD COLUMN     "logo" VARCHAR(500),
ADD COLUMN     "organization" VARCHAR(100);

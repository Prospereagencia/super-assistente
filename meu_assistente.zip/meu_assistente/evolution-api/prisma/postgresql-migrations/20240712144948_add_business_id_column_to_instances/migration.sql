-- AlterTable
ALTER TABLE "Instance" ADD COLUMN     "businessId" VARCHAR(100);

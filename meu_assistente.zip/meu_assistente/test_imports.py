"""
Teste das importações das APIs Google
"""

def test_google_imports():
    print("🧪 Testando importações do Google...")
    
    try:
        from google.auth.transport.requests import Request
        print("✅ google.auth.transport.requests - OK")
    except ImportError as e:
        print(f"❌ google.auth.transport.requests - {e}")
    
    try:
        from google.oauth2.credentials import Credentials
        print("✅ google.oauth2.credentials - OK")
    except ImportError as e:
        print(f"❌ google.oauth2.credentials - {e}")
    
    try:
        from google_auth_oauthlib.flow import InstalledAppFlow
        print("✅ google_auth_oauthlib.flow - OK")
    except ImportError as e:
        print(f"❌ google_auth_oauthlib.flow - {e}")
    
    try:
        from googleapiclient.discovery import build
        print("✅ googleapiclient.discovery - OK")
    except ImportError as e:
        print(f"❌ googleapiclient.discovery - {e}")
    
    print("\n🎉 Teste de importações concluído!")

if __name__ == "__main__":
    test_google_imports()
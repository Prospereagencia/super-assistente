# 🤖 Meu Assistente Pessoal

Um assistente pessoal inteligente construído com CrewAI para ajudar com tarefas diárias.

## 🚀 Instalação

```bash
cd meu_assistente
pip install -e .
```

## 📋 Uso

### Apresentação do assistente
```bash
python -m meu_assistente.main apresentacao
```

### Organizar tarefas
```bash
python -m meu_assistente.main organizar
```

### Pesquisar informações
```bash
python -m meu_assistente.main pesquisar
```

## 📁 Estrutura do Projeto

```
meu_assistente/
├── pyproject.toml          # Configuração do projeto
├── README.md              # Este arquivo
└── src/
    └── meu_assistente/
        ├── __init__.py    # Inicialização do pacote
        ├── main.py        # Ponto de entrada
        ├── crew.py        # Lógica principal do CrewAI
        ├── config/        # Configurações
        │   ├── agents.yaml # Definição dos agentes
        │   └── tasks.yaml  # Definição das tarefas
        └── tools/         # Futuras integrações
```

## 🔧 Personalização

- **Agentes**: Edite `src/meu_assistente/config/agents.yaml`
- **Tarefas**: Edite `src/meu_assistente/config/tasks.yaml`
- **Ferramentas**: Adicione em `src/meu_assistente/tools/`

## 📝 Próximos Passos

- [ ] Integração com Google Calendar
- [ ] Integração com WhatsApp
- [ ] Interface web
- [ ] Persistência de dados
```

Para testar a nova estrutura:

```bash
cd meu_assistente
```

```bash
pip install -e .
```

```bash
python -m meu_assistente.main apresentacao
"""
Meu Assistente Pessoal - Um assistente baseado em CrewAI
"""

from .crew import MeuAssistenteCrew
from .main import main

__version__ = "0.1.0"
__all__ = ["MeuAssistenteCrew", "main"]
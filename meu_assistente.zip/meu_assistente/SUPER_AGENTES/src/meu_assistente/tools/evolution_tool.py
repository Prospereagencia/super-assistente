"""
Integração com Evolution API para WhatsApp
"""

import os
import requests
import json
from typing import Optional, Dict, Any, List
from crewai_tools import BaseTool
from dotenv import load_dotenv

load_dotenv()

class EvolutionTool(BaseTool):
    name: str = "Evolution WhatsApp"
    description: str = """
    Ferramenta para integração com WhatsApp via Evolution API.
    Permite:
    - Enviar mensagens de texto
    - Enviar imagens e documentos
    - Verificar status de mensagens
    - Gerenciar contatos
    - Criar grupos
    """
    
    def __init__(self):
        super().__init__()
        self.api_url = os.getenv("EVOLUTION_API_URL")
        self.api_key = os.getenv("EVOLUTION_API_KEY")
        self.instance_name = os.getenv("EVOLUTION_INSTANCE_NAME")
        self.headers = {
            "Content-Type": "application/json",
            "apikey": self.api_key
        }
    
    def _run(self, action: str, **kwargs) -> str:
        """
        Executa uma ação na Evolution API
        
        Args:
            action: Ação a ser executada (send_text, send_media, get_contacts, etc.)
            **kwargs: Parâmetros específicos da ação
        """
        try:
            if action == "send_text":
                return self._send_text_message(**kwargs)
            elif action == "send_media":
                return self._send_media_message(**kwargs)
            elif action == "get_contacts":
                return self._get_contacts()
            elif action == "create_group":
                return self._create_group(**kwargs)
            elif action == "get_instance_status":
                return self._get_instance_status()
            else:
                return f"Ação '{action}' não reconhecida"
                
        except Exception as e:
            return f"Erro na Evolution API: {str(e)}"
    
    def _send_text_message(self, number: str, message: str) -> str:
        """Envia mensagem de texto"""
        url = f"{self.api_url}/message/sendText/{self.instance_name}"
        
        payload = {
            "number": number,
            "text": message
        }
        
        response = requests.post(url, headers=self.headers, json=payload)
        
        if response.status_code == 200:
            return f"Mensagem enviada com sucesso para {number}"
        else:
            return f"Erro ao enviar mensagem: {response.text}"
    
    def _send_media_message(self, number: str, media_url: str, caption: str = "", media_type: str = "image") -> str:
        """Envia mensagem com mídia"""
        url = f"{self.api_url}/message/sendMedia/{self.instance_name}"
        
        payload = {
            "number": number,
            "mediatype": media_type,
            "media": media_url,
            "caption": caption
        }
        
        response = requests.post(url, headers=self.headers, json=payload)
        
        if response.status_code == 200:
            return f"Mídia enviada com sucesso para {number}"
        else:
            return f"Erro ao enviar mídia: {response.text}"
    
    def _get_contacts(self) -> str:
        """Obtém lista de contatos"""
        url = f"{self.api_url}/chat/findContacts/{self.instance_name}"
        
        response = requests.get(url, headers=self.headers)
        
        if response.status_code == 200:
            contacts = response.json()
            return f"Encontrados {len(contacts)} contatos"
        else:
            return f"Erro ao obter contatos: {response.text}"
    
    def _create_group(self, group_name: str, participants: List[str]) -> str:
        """Cria um grupo no WhatsApp"""
        url = f"{self.api_url}/group/create/{self.instance_name}"
        
        payload = {
            "subject": group_name,
            "participants": participants
        }
        
        response = requests.post(url, headers=self.headers, json=payload)
        
        if response.status_code == 200:
            return f"Grupo '{group_name}' criado com sucesso"
        else:
            return f"Erro ao criar grupo: {response.text}"
    
    def _get_instance_status(self) -> str:
        """Verifica status da instância"""
        url = f"{self.api_url}/instance/connectionState/{self.instance_name}"
        
        response = requests.get(url, headers=self.headers)
        
        if response.status_code == 200:
            status = response.json()
            return f"Status da instância: {status.get('state', 'Desconhecido')}"
        else:
            return f"Erro ao verificar status: {response.text}"
    
    def send_notification(self, number: str, title: str, message: str) -> str:
        """Envia uma notificação formatada"""
        formatted_message = f"🔔 *{title}*\n\n{message}"
        return self._send_text_message(number, formatted_message)
    
    def send_task_reminder(self, number: str, task: str, deadline: str) -> str:
        """Envia lembrete de tarefa"""
        message = f"⏰ *Lembrete de Tarefa*\n\n📋 Tarefa: {task}\n⏳ Prazo: {deadline}"
        return self._send_text_message(number, message)
    
    def broadcast_message(self, numbers: List[str], message: str) -> str:
        """Envia mensagem para múltiplos contatos"""
        results = []
        for number in numbers:
            result = self._send_text_message(number, message)
            results.append(f"{number}: {result}")
        
        return "\n".join(results)
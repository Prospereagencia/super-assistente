"""
Integração com Google Drive
"""

import os
from typing import List, Dict, Any
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from crewai_tools import BaseTool
from dotenv import load_dotenv

load_dotenv()

class GoogleDriveTool(BaseTool):
    name: str = "Google Drive"
    description: str = """
    Ferramenta para integração com Google Drive.
    Permite:
    - Listar arquivos recentes
    - Buscar arquivos por nome
    - Obter informações de arquivos
    - Listar arquivos compartilhados
    """
    
    def __init__(self):
        super().__init__()
        self.scopes = ['https://www.googleapis.com/auth/drive.readonly']
        self.credentials_file = os.getenv('GOOGLE_CREDENTIALS_FILE', 'credentials.json')
        self.token_file = 'drive_token.json'
        self.service = None
        self._authenticate()
    
    def _authenticate(self):
        """Autentica com Google Drive API"""
        creds = None
        
        if os.path.exists(self.token_file):
            creds = Credentials.from_authorized_user_file(self.token_file, self.scopes)
        
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                if os.path.exists(self.credentials_file):
                    flow = InstalledAppFlow.from_client_secrets_file(
                        self.credentials_file, self.scopes)
                    creds = flow.run_local_server(port=0)
                else:
                    raise FileNotFoundError(f"Arquivo {self.credentials_file} não encontrado")
            
            with open(self.token_file, 'w') as token:
                token.write(creds.to_json())
        
        self.service = build('drive', 'v3', credentials=creds)
    
    def _run(self, action: str, **kwargs) -> str:
        """Executa uma ação no Google Drive"""
        try:
            if action == "list_files":
                return self._list_recent_files(**kwargs)
            elif action == "search_files":
                return self._search_files(**kwargs)
            elif action == "shared_files":
                return self._list_shared_files()
            elif action == "storage_info":
                return self._get_storage_info()
            else:
                return f"Ação '{action}' não reconhecida"
                
        except Exception as e:
            return f"Erro no Google Drive: {str(e)}"
    
    def _list_recent_files(self, max_results: int = 10) -> str:
        """Lista arquivos recentes"""
        results = self.service.files().list(
            pageSize=max_results,
            fields="nextPageToken, files(id, name, mimeType, modifiedTime, size)",
            orderBy="modifiedTime desc"
        ).execute()
        
        items = results.get('files', [])
        
        if not items:
            return "Nenhum arquivo encontrado"
        
        file_list = []
        for item in items:
            name = item['name']
            file_type = self._get_file_type(item['mimeType'])
            modified = item.get('modifiedTime', 'Data desconhecida')
            size = self._format_size(item.get('size', '0'))
            
            file_list.append(f"• {name} ({file_type}) - {size} - {modified[:10]}")
        
        return f"Arquivos recentes ({len(file_list)}):\n" + "\n".join(file_list)
    
    def _search_files(self, query: str, max_results: int = 10) -> str:
        """Busca arquivos por nome"""
        search_query = f"name contains '{query}'"
        
        results = self.service.files().list(
            q=search_query,
            pageSize=max_results,
            fields="nextPageToken, files(id, name, mimeType, modifiedTime)"
        ).execute()
        
        items = results.get('files', [])
        
        if not items:
            return f"Nenhum arquivo encontrado para: {query}"
        
        file_list = []
        for item in items:
            name = item['name']
            file_type = self._get_file_type(item['mimeType'])
            modified = item.get('modifiedTime', 'Data desconhecida')
            
            file_list.append(f"• {name} ({file_type}) - {modified[:10]}")
        
        return f"Arquivos encontrados para '{query}' ({len(file_list)}):\n" + "\n".join(file_list)
    
    def _list_shared_files(self) -> str:
        """Lista arquivos compartilhados comigo"""
        results = self.service.files().list(
            q="sharedWithMe=true",
            pageSize=10,
            fields="nextPageToken, files(id, name, mimeType, owners)"
        ).execute()
        
        items = results.get('files', [])
        
        if not items:
            return "Nenhum arquivo compartilhado encontrado"
        
        file_list = []
        for item in items:
            name = item['name']
            file_type = self._get_file_type(item['mimeType'])
            owners = item.get('owners', [])
            owner_name = owners[0]['displayName'] if owners else 'Desconhecido'
            
            file_list.append(f"• {name} ({file_type}) - Compartilhado por: {owner_name}")
        
        return f"Arquivos compartilhados ({len(file_list)}):\n" + "\n".join(file_list)
    
    def _get_storage_info(self) -> str:
        """Obtém informações de armazenamento"""
        about = self.service.about().get(fields="storageQuota").execute()
        quota = about.get('storageQuota', {})
        
        limit = int(quota.get('limit', 0))
        usage = int(quota.get('usage', 0))
        
        if limit > 0:
            used_percent = (usage / limit) * 100
            limit_gb = limit / (1024**3)
            usage_gb = usage / (1024**3)
            
            return f"💾 Armazenamento Google Drive:\n• Usado: {usage_gb:.2f} GB de {limit_gb:.2f} GB ({used_percent:.1f}%)"
        else:
            usage_gb = usage / (1024**3)
            return f"💾 Armazenamento usado: {usage_gb:.2f} GB"
    
    def _get_file_type(self, mime_type: str) -> str:
        """Converte MIME type para tipo legível"""
        type_map = {
            'application/vnd.google-apps.document': 'Google Docs',
            'application/vnd.google-apps.spreadsheet': 'Google Sheets',
            'application/vnd.google-apps.presentation': 'Google Slides',
            'application/vnd.google-apps.folder': 'Pasta',
            'application/pdf': 'PDF',
            'image/jpeg': 'Imagem',
            'image/png': 'Imagem',
            'text/plain': 'Texto',
            'application/zip': 'ZIP'
        }
        return type_map.get(mime_type, 'Arquivo')
    
    def _format_size(self, size_str: str) -> str:
        """Formata tamanho do arquivo"""
        try:
            size = int(size_str)
            if size < 1024:
                return f"{size} B"
            elif size < 1024**2:
                return f"{size/1024:.1f} KB"
            elif size < 1024**3:
                return f"{size/(1024**2):.1f} MB"
            else:
                return f"{size/(1024**3):.1f} GB"
        except (ValueError, TypeError):
            return "Tamanho desconhecido"
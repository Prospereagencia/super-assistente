"""
Integração com Gmail
"""

import os
import base64
from typing import List, Dict, Any
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from crewai_tools import BaseTool
from dotenv import load_dotenv

load_dotenv()

class GmailTool(BaseTool):
    name: str = "Gmail"
    description: str = """
    Ferramenta para integração com Gmail.
    Permite:
    - Ler emails recentes
    - Buscar emails por assunto/remetente
    - Contar emails não lidos
    - Obter resumo da caixa de entrada
    """
    
    def __init__(self):
        super().__init__()
        self.scopes = ['https://www.googleapis.com/auth/gmail.readonly']
        self.credentials_file = os.getenv('GOOGLE_CREDENTIALS_FILE', 'credentials.json')
        self.token_file = 'gmail_token.json'
        self.service = None
        self._authenticate()
    
    def _authenticate(self):
        """Autentica com Gmail API"""
        creds = None
        
        if os.path.exists(self.token_file):
            creds = Credentials.from_authorized_user_file(self.token_file, self.scopes)
        
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                if os.path.exists(self.credentials_file):
                    flow = InstalledAppFlow.from_client_secrets_file(
                        self.credentials_file, self.scopes)
                    creds = flow.run_local_server(port=0)
                else:
                    raise FileNotFoundError(f"Arquivo {self.credentials_file} não encontrado")
            
            with open(self.token_file, 'w') as token:
                token.write(creds.to_json())
        
        self.service = build('gmail', 'v1', credentials=creds)
    
    def _run(self, action: str, **kwargs) -> str:
        """Executa uma ação no Gmail"""
        try:
            if action == "unread_count":
                return self._get_unread_count()
            elif action == "recent_emails":
                return self._get_recent_emails(**kwargs)
            elif action == "search_emails":
                return self._search_emails(**kwargs)
            elif action == "inbox_summary":
                return self._get_inbox_summary()
            else:
                return f"Ação '{action}' não reconhecida"
                
        except Exception as e:
            return f"Erro no Gmail: {str(e)}"
    
    def _get_unread_count(self) -> str:
        """Conta emails não lidos"""
        results = self.service.users().messages().list(
            userId='me', q='is:unread'
        ).execute()
        
        messages = results.get('messages', [])
        count = len(messages)
        
        return f"Você tem {count} email(s) não lido(s)"
    
    def _get_recent_emails(self, max_results: int = 5) -> str:
        """Obtém emails recentes"""
        results = self.service.users().messages().list(
            userId='me', maxResults=max_results
        ).execute()
        
        messages = results.get('messages', [])
        
        if not messages:
            return "Nenhum email encontrado"
        
        email_list = []
        for message in messages[:max_results]:
            msg = self.service.users().messages().get(
                userId='me', id=message['id']
            ).execute()
            
            headers = msg['payload'].get('headers', [])
            subject = next((h['value'] for h in headers if h['name'] == 'Subject'), 'Sem assunto')
            sender = next((h['value'] for h in headers if h['name'] == 'From'), 'Remetente desconhecido')
            
            email_list.append(f"• {subject} - De: {sender}")
        
        return f"Últimos {len(email_list)} emails:\n" + "\n".join(email_list)
    
    def _search_emails(self, query: str, max_results: int = 5) -> str:
        """Busca emails por query"""
        results = self.service.users().messages().list(
            userId='me', q=query, maxResults=max_results
        ).execute()
        
        messages = results.get('messages', [])
        
        if not messages:
            return f"Nenhum email encontrado para: {query}"
        
        email_list = []
        for message in messages:
            msg = self.service.users().messages().get(
                userId='me', id=message['id']
            ).execute()
            
            headers = msg['payload'].get('headers', [])
            subject = next((h['value'] for h in headers if h['name'] == 'Subject'), 'Sem assunto')
            sender = next((h['value'] for h in headers if h['name'] == 'From'), 'Remetente desconhecido')
            
            email_list.append(f"• {subject} - De: {sender}")
        
        return f"Emails encontrados para '{query}' ({len(email_list)}):\n" + "\n".join(email_list)
    
    def _get_inbox_summary(self) -> str:
        """Obtém resumo da caixa de entrada"""
        try:
            # Contar emails não lidos
            unread_result = self.service.users().messages().list(
                userId='me', q='is:unread'
            ).execute()
            unread_count = len(unread_result.get('messages', []))
            
            # Obter informações gerais da caixa de entrada
            profile = self.service.users().getProfile(userId='me').execute()
            total_messages = profile.get('messagesTotal', 0)
            total_threads = profile.get('threadsTotal', 0)
            
            # Contar emails de hoje
            today_result = self.service.users().messages().list(
                userId='me', q='newer_than:1d'
            ).execute()
            today_count = len(today_result.get('messages', []))
            
            # Contar emails importantes
            important_result = self.service.users().messages().list(
                userId='me', q='is:important'
            ).execute()
            important_count = len(important_result.get('messages', []))
            
            summary = f"""📧 Resumo do Gmail:
• Total de mensagens: {total_messages}
• Total de conversas: {total_threads}
• Não lidos: {unread_count}
• Recebidos hoje: {today_count}
• Marcados como importantes: {important_count}"""
            
            return summary
            
        except Exception as e:
            return f"Erro ao obter resumo do Gmail: {str(e)}"
    
    def get_important_emails(self) -> str:
        """Obtém emails importantes"""
        return self._search_emails("is:important", max_results=3)
    
    def get_emails_from_sender(self, sender: str) -> str:
        """Obtém emails de um remetente específico"""
        query = f"from:{sender}"
        return self._search_emails(query, max_results=5)
    
    def get_unread_emails(self) -> str:
        """Obtém emails não lidos"""
        results = self.service.users().messages().list(
            userId='me', q='is:unread', maxResults=5
        ).execute()
        
        messages = results.get('messages', [])
        
        if not messages:
            return "Nenhum email não lido"
        
        email_list = []
        for message in messages:
            msg = self.service.users().messages().get(
                userId='me', id=message['id']
            ).execute()
            
            headers = msg['payload'].get('headers', [])
            subject = next((h['value'] for h in headers if h['name'] == 'Subject'), 'Sem assunto')
            sender = next((h['value'] for h in headers if h['name'] == 'From'), 'Remetente desconhecido')
            
            email_list.append(f"• {subject} - De: {sender}")
        
        return f"Emails não lidos ({len(email_list)}):\n" + "\n".join(email_list)
    
    def get_today_summary(self) -> str:
        """Obtém resumo dos emails de hoje"""
        try:
            # Emails recebidos hoje
            received_today = self.service.users().messages().list(
                userId='me', q='newer_than:1d'
            ).execute()
            received_count = len(received_today.get('messages', []))
            
            # Emails não lidos de hoje
            unread_today = self.service.users().messages().list(
                userId='me', q='is:unread newer_than:1d'
            ).execute()
            unread_today_count = len(unread_today.get('messages', []))
            
            summary = f"""📅 Resumo de hoje:
• Emails recebidos: {received_count}
• Não lidos de hoje: {unread_today_count}"""
            
            return summary
            
        except Exception as e:
            return f"Erro ao obter resumo de hoje: {str(e)}"
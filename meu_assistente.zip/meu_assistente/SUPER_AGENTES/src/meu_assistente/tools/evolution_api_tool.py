# src/meu_assistente/tools/evolution_api_tool.py

from crewai_tools import tool
import requests
import os

@tool
def enviar_mensagem_whatsapp(mensagem: str, numero: str) -> str:
    """Envia uma mensagem para o número de WhatsApp indicado usando a Evolution API."""
    
    token = os.getenv("EVOLUTION_API_TOKEN")
    if not token:
        return "Token da API não configurado. Defina EVOLUTION_API_TOKEN no ambiente."

    url = "https://api.evolutionapi.com/message/sendText"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    payload = {
        "number": numero,
        "text": mensagem
    }

    response = requests.post(url, json=payload, headers=headers)
    if response.status_code == 200:
        return f"Mensagem enviada com sucesso para {numero}!"
    else:
        return f"Erro ao enviar mensagem: {response.status_code} - {response.text}"

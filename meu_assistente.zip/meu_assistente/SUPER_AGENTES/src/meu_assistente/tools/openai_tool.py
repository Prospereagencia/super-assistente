"""
Integração com OpenAI para funcionalidades avançadas de IA
"""

import os
from typing import Optional, Dict, Any
from openai import OpenAI
from crewai_tools import BaseTool
from dotenv import load_dotenv

load_dotenv()

class OpenAITool(BaseTool):
    name: str = "OpenAI Assistant"
    description: str = """
    Ferramenta para interagir com modelos avançados da OpenAI.
    Útil para:
    - Análise de texto complexa
    - Geração de conteúdo criativo
    - Tradução de idiomas
    - Resumo de documentos
    - Análise de sentimentos
    """
    
    def __init__(self):
        super().__init__()
        self.client = OpenAI(
            api_key=os.getenv("OPENAI_API_KEY")
        )
        self.model = os.getenv("OPENAI_MODEL", "gpt-4-turbo-preview")
    
    def _run(self, prompt: str, task_type: str = "general", **kwargs) -> str:
        """
        Executa uma consulta para a OpenAI
        
        Args:
            prompt: O prompt/pergunta para a IA
            task_type: Tipo de tarefa (general, creative, analysis, translation, summary)
            **kwargs: Parâmetros adicionais
        """
        try:
            # Configurar parâmetros baseado no tipo de tarefa
            params = self._get_task_params(task_type)
            params.update(kwargs)
            
            # Preparar mensagens
            messages = [
                {"role": "system", "content": self._get_system_prompt(task_type)},
                {"role": "user", "content": prompt}
            ]
            
            # Fazer a chamada para a API
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                **params
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return f"Erro ao consultar OpenAI: {str(e)}"
    
    def _get_system_prompt(self, task_type: str) -> str:
        """Retorna o prompt do sistema baseado no tipo de tarefa"""
        prompts = {
            "general": "Você é um assistente útil e preciso. Responda de forma clara e objetiva.",
            "creative": "Você é um assistente criativo. Gere conteúdo original e interessante.",
            "analysis": "Você é um analista experiente. Forneça análises detalhadas e insights valiosos.",
            "translation": "Você é um tradutor profissional. Traduza com precisão mantendo o contexto.",
            "summary": "Você é especialista em resumos. Extraia os pontos principais de forma concisa."
        }
        return prompts.get(task_type, prompts["general"])
    
    def _get_task_params(self, task_type: str) -> Dict[str, Any]:
        """Retorna parâmetros otimizados para cada tipo de tarefa"""
        params_map = {
            "general": {"temperature": 0.7, "max_tokens": 1000},
            "creative": {"temperature": 0.9, "max_tokens": 1500},
            "analysis": {"temperature": 0.3, "max_tokens": 2000},
            "translation": {"temperature": 0.2, "max_tokens": 1000},
            "summary": {"temperature": 0.4, "max_tokens": 800}
        }
        return params_map.get(task_type, params_map["general"])
    
    def generate_creative_content(self, topic: str, content_type: str = "texto") -> str:
        """Gera conteúdo criativo sobre um tópico"""
        prompt = f"Crie um {content_type} criativo e interessante sobre: {topic}"
        return self._run(prompt, "creative")
    
    def analyze_text(self, text: str, analysis_type: str = "geral") -> str:
        """Analisa um texto"""
        prompt = f"Faça uma análise {analysis_type} do seguinte texto:\n\n{text}"
        return self._run(prompt, "analysis")
    
    def translate_text(self, text: str, target_language: str = "português") -> str:
        """Traduz texto para o idioma especificado"""
        prompt = f"Traduza o seguinte texto para {target_language}:\n\n{text}"
        return self._run(prompt, "translation")
    
    def summarize_text(self, text: str, max_sentences: int = 3) -> str:
        """Resume um texto"""
        prompt = f"Resuma o seguinte texto em no máximo {max_sentences} frases:\n\n{text}"
        return self._run(prompt, "summary")
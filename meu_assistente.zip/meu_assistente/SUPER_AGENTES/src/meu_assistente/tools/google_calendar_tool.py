# src/meu_assistente/tools/google_calendar_tool.py

from crewai_tools import tool
import datetime
import os
import pickle
import google.auth.transport.requests
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

@tool
def agendar_evento_google_calendar(descricao: str, data: str, hora: str) -> str:
    """Agenda um evento no Google Calendar. Informe a descrição, data (YYYY-MM-DD) e hora (HH:MM)."""

    SCOPES = ['https://www.googleapis.com/auth/calendar']
    creds = None

    if os.path.exists('src/meu_assistente/tools/token_calendar.pkl'):
        with open('src/meu_assistente/tools/token_calendar.pkl', 'rb') as token:
            creds = pickle.load(token)
    else:
        flow = InstalledAppFlow.from_client_secrets_file(
            'src/meu_assistente/tools/token_oauth.json', SCOPES)
        creds = flow.run_local_server(port=0)
        with open('src/meu_assistente/tools/token_calendar.pkl', 'wb') as token:
            pickle.dump(creds, token)

    service = build('calendar', 'v3', credentials=creds)

    start = f"{data}T{hora}:00"
    end = f"{data}T{str(int(hora.split(':')[0])+1)}:{hora.split(':')[1]}:00"

    event = {
        'summary': descricao,
        'start': {'dateTime': start, 'timeZone': 'America/Sao_Paulo'},
        'end': {'dateTime': end, 'timeZone': 'America/Sao_Paulo'},
    }

    event = service.events().insert(calendarId='primary', body=event).execute()
    return f"Evento criado: {event.get('htmlLink')}"

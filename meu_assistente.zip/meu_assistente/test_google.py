"""
Teste das integrações Google
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

def test_google_apis():
    print("🧪 Testando APIs do Google...")
    print("=" * 50)
    
    # Testar Google Calendar
    try:
        from meu_assistente.tools.google_calendar_tool import GoogleCalendarTool
        calendar_tool = GoogleCalendarTool()
        result = calendar_tool._run("get_today_events")
        print("✅ Google Calendar: OK")
        print(f"   {result}")
    except Exception as e:
        print(f"❌ Google Calendar: {e}")
    
    print("-" * 50)
    
    # Testar Gmail
    try:
        from meu_assistente.tools.gmail_tool import GmailTool
        gmail_tool = GmailTool()
        result = gmail_tool._run("unread_count")
        print("✅ Gmail: OK")
        print(f"   {result}")
    except Exception as e:
        print(f"❌ Gmail: {e}")
    
    print("-" * 50)
    
    # Testar Google Drive
    try:
        from meu_assistente.tools.google_drive_tool import GoogleDriveTool
        drive_tool = GoogleDriveTool()
        result = drive_tool._run("storage_info")
        print("✅ Google Drive: OK")
        print(f"   {result}")
    except Exception as e:
        print(f"❌ Google Drive: {e}")

if __name__ == "__main__":
    test_google_apis()